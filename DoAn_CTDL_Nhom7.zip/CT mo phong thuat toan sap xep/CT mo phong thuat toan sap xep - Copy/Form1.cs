﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//https://www.youtube.com/watch?v=XnDSr9PpjVc
//https://www.youtube.com/watch?v=Ppyt82gkWk8
namespace CT_mo_phong_thuat_toan_sap_xep
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        // Tạo biến random chứa giá trị số ngẫu nhiên cho nút   
        Random rd = new Random();
        int[] M = new int[0]; // mảng M chứa giá trị nguyên
        Button[] Mn = new Button[0]; // tạo mảng nút
        int HEIGHT = 100;// chiều cao lúc di chuyển của button là 100
        int SIZE = 50; // kích thước của nút
        int KHOANGCACHNUT = 50;
        private void btnVeNut_Click(object sender, EventArgs e)
        {
            // lấy giá trị n nhập từ bàn phím
            int n = int.Parse(txtSoNut.Text.Trim());
            M = new int[n]; // khởi tạo mảng M có n phần tử
            Mn = new Button[n];
            //int[] b = { 1,2,3,4,5,6,7,8,9,10};
            // Xáo giao diện cũ đi trong pnNut
            pnNut.Controls.Clear();
            for (int i = 0; i < n; i++)
            {
                // khởi tạo 1 button btn
                Button btn = new Button();
                // lấy giá trị ngẫu nhiên từ 0 đến 99
                //int value = b[i];
                int value = rd.Next(100);
                btn.Text = value + ""; // thêm giá trị số ngẫu nhiên vào nút
                btn.Width = btn.Height = SIZE;
                // tạo vị trí button trên giao diện hàm point vẽ button trên trục x và y
                // đổi số 1 là trục x, đổi số 2 trong hàm là trục y
                btn.Location = new Point(KHOANGCACHNUT + pnNut.Controls.Count * (btn.Width + KHOANGCACHNUT), pnNut.Height / 2 - btn.Height / 2); // cho nút xuất hiện ở giữa trong pnNut
                // ADD nút vào pnNut
                btn.BackColor = Color.White;
                pnNut.Controls.Add(btn);
                // gán giá trị số ngẫu nhiên cho từng phần tử mảng
                // gán từng nút cho mảng Mn
                M[i] = value;
                Mn[i] = btn;
            }
        }
        private void btnSapXep_Click(object sender, EventArgs e)
        {
            // tạo điều kiện nếu người dùng chọn vào item trong combobox
            if (cboThuatToanSapXep.SelectedIndex == -1)
            {
                MessageBox.Show("Bạn lựa chọn thuật toán sắp xếp");
            }
            else if (cboThuatToanSapXep.SelectedIndex == 0)
            {
                // tiếp theo mình kéo backgroudworker vào giao diện phần mềm
                backgroundWorker1.RunWorkerAsync(); // gọi hàm doword 
            }
            else if (cboThuatToanSapXep.SelectedIndex == 1)
            {
                // tiếp theo mình kéo backgroudworker vào giao diện phần mềm
                backgroundWorker2.RunWorkerAsync(); // gọi hàm doword 
            }
            else if (cboThuatToanSapXep.SelectedIndex == 2)
            {
                backgroundWorker5.RunWorkerAsync(); // gọi hàm doword 
            }
            else if (cboThuatToanSapXep.SelectedIndex == 3)
            {
                backgroundWorker3.RunWorkerAsync(); // gọi hàm doword 
            }
            else if (cboThuatToanSapXep.SelectedIndex == 4)
            {
                backgroundWorker4.RunWorkerAsync(); // gọi hàm doword 
            }
        }
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            // hàm dowork xử lý thông tin nhưng không cập nhật được giao diện
            // hàm doword kết thúc nó sẽ gọi hàm completed

            // tạo 1 hàm sắp xếp 
            BubbleSort(M);// truyền vào mảng M
        }
        private void BubbleSort(int[] M)
        {
            int i, j;
            Status st = new Status(); // khởi tạo vị trí st
            for (i = 0; i < M.Length; i++)
            {
                for (j = M.Length - 1; j > i; j--)
                {
                    if (M[j] < M[j - 1])
                    {
                        int tam = M[j];
                        M[j] = M[j - 1];
                        M[j - 1] = tam;
                        System.Threading.Thread.Sleep(5);// delay cho người dùng xem nút di chuyển
                        // tiếp tục tạo hàm di chuyển nút
                        DiChuyenSelectionSort(j, j - 1);

                    }
                }
            }
        }
        private void DiChuyenSelectionSort(int vt1, int vt2)
        {
            Status st = new Status();
            st.Vt1 = vt1;
            st.Vt2 = vt2;
            st.Type = LoaiDiChuyen.DI_LEN_DI_XUONG;
            for (int x = 0; x < HEIGHT; x++) // đi lên đi xuống bằng chiều cao HEIGHT khởi tạo ban đầu là 100
            {
                // đối số 1 là 0, tức là không quan tâm phần trăm chạy
                // các bạn tưởng tượng giống phần loading của game vừa load vào
                // ở phần mềm mình để 0 là không quan tâm đến nó
                // đối số 2 là lấy vị trí của nút
                backgroundWorker1.ReportProgress(0, st); // gọi hàm Progress để cập nhật giao diện
                System.Threading.Thread.Sleep(5);
            } // thành công làm tiếp
            st.Type = LoaiDiChuyen.QUA_PHAI_QUA_TRAI;
            int WIDTH = Math.Abs(vt1 - vt2) * (SIZE + KHOANGCACHNUT);
            for (int x = 0; x < WIDTH; x++)
            {
                backgroundWorker1.ReportProgress(0, st); // gọi hàm Progress để cập nhật giao diện
                System.Threading.Thread.Sleep(5);
            }// oklàm tiếp cho nút di chuyển ngược lại đi xuống đi lên để vào 1 hàng
            st.Type = LoaiDiChuyen.DI_XUONG_DI_LEN;
            for (int x = 0; x < HEIGHT; x++)
            {
                backgroundWorker1.ReportProgress(0, st); // gọi hàm Progress để cập nhật giao diện
                System.Threading.Thread.Sleep(5);
            }// làm tiếp trường hợp dừng
            st.Type = LoaiDiChuyen.DUNG;
            backgroundWorker1.ReportProgress(0, st);
        }
        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // cập nhật giao diện thời gian thực hiện xong chuyển đến hàm dowork
            Status st = e.UserState as Status;
            if (st == null) return; // không làm gì cả
            // dừng đã làm rồi
            if (st.Type == LoaiDiChuyen.DUNG)// nếu dừng tiến trình thì thay đổi giá trị của 2 nút trong mảng
            {
                Button tam = Mn[st.Vt2];
                Mn[st.Vt2] = Mn[st.Vt1];
                Mn[st.Vt1] = tam;
                return;
            }
            Button btn1 = Mn[st.Vt1];
            Button btn2 = Mn[st.Vt2];
            if (st.Type == LoaiDiChuyen.DI_LEN_DI_XUONG)
            {
                btn1.Top = btn1.Top + 1; // nút 1 đi lên
                btn2.Top = btn2.Top - 1;// nút 2 đi xuống
            }
            else if (st.Type == LoaiDiChuyen.QUA_PHAI_QUA_TRAI)
            {
                btn1.Left = btn1.Left - 1; //nút 1 qua phải 
                btn2.Left = btn2.Left + 1; // nút 2 qua trái
            }
            else if (st.Type == LoaiDiChuyen.DI_XUONG_DI_LEN)
            {
                btn1.Top = btn1.Top - 1;// nút 1 đi xuống
                btn2.Top = btn2.Top + 1;// nút 2 đi lên
            }

        }
        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // kết thúc tiến trình cho nút màu xanh lá cây
            // chữ màu đỏ
            foreach (Button btn in pnNut.Controls) // duyệt danh sách ở trong pnnut
            {
                btn.BackColor = Color.Green;
                btn.ForeColor = Color.White;
            }
            btnSapXep.Enabled = true;// nãi cho mở giờ hiện lại cho người dùng tiếp tục
            btnVeNut.Enabled = true;
        }
        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            // tạo hàm sắp xếp interchange Sort
            InterchangeSort(M);
        }
        private void InterchangeSort(int[] m)
        {
            int i, j;
            Status st = new Status();
            for (i = 0; i < M.Length - 1; i++)
                for (j = i + 1; j < M.Length; j++)
                    if (M[j] < M[i])
                    {
                        int tam = M[i];
                        M[i] = M[j];
                        M[j] = tam;
                        System.Threading.Thread.Sleep(15);
                        // hàm di chuyển nút
                        DiChuyenInterchangeSort(j, i);
                    }
        }
        private void DiChuyenInterchangeSort(int vt1, int vt2)
        {
            Status st = new Status();
            st.Vt1 = vt1;
            st.Vt2 = vt2;
            st.Type = LoaiDiChuyen.DI_LEN_DI_XUONG;
            for (int x = 0; x < HEIGHT; x++)
            {
                backgroundWorker2.ReportProgress(0, st);
                System.Threading.Thread.Sleep(5);
            } // ok làm tiếp
            st.Type = LoaiDiChuyen.QUA_PHAI_QUA_TRAI;
            int WIDTH = Math.Abs(vt1 - vt2) * (SIZE + KHOANGCACHNUT);
            for (int x = 0; x < WIDTH; x++)
            {
                backgroundWorker2.ReportProgress(0, st);
                System.Threading.Thread.Sleep(5);
            }// ok làm tiếp
            st.Type = LoaiDiChuyen.DI_XUONG_DI_LEN;
            for (int x = 0; x < HEIGHT; x++)
            {
                backgroundWorker2.ReportProgress(0, st);
                System.Threading.Thread.Sleep(5);
            }
            st.Type = LoaiDiChuyen.DUNG;
            backgroundWorker2.ReportProgress(0, st);
        }
        private void backgroundWorker2_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Status st = e.UserState as Status; // usertate là lấy giá trị st truyền vào trong hàm
            if (st == null) return;
            if (st.Type == LoaiDiChuyen.DUNG)
            {
                Button tam = Mn[st.Vt2];
                Mn[st.Vt2] = Mn[st.Vt1];
                Mn[st.Vt1] = tam;
                return;
            }
            Button btn1 = Mn[st.Vt1];
            Button btn2 = Mn[st.Vt2];
            if (st.Type == LoaiDiChuyen.DI_LEN_DI_XUONG)
            {
                btn1.Top = btn1.Top - 1;
                btn2.Top = btn2.Top + 1;
            }
            else if (st.Type == LoaiDiChuyen.QUA_PHAI_QUA_TRAI)
            {
                btn1.Left = btn1.Left - 1;
                btn2.Left = btn2.Left + 1;
            }
            else if (st.Type == LoaiDiChuyen.DI_XUONG_DI_LEN)
            {
                btn1.Top = btn1.Top + 1;
                btn2.Top = btn2.Top - 1;
            }
        }
        private void backgroundWorker2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            foreach (Button btn in pnNut.Controls)
            {
                btn.BackColor = Color.Green;
                btn.ForeColor = Color.White;
            }
            btnSapXep.Enabled = true;
            btnVeNut.Enabled = true;
        }
        private void backgroundWorker3_DoWork(object sender, DoWorkEventArgs e)
        {
            QuickSort(M, 0, M.Length - 1);
        }

        private void QuickSort(int[] m, int First, int Last)
        {
            int i, j, tam, mid;
            mid = M[(First + Last) / 2];
            i = First;
            j = Last;
            do
            {
                while (M[i] < mid) i++;
                while (M[j] > mid) j--;
                if (i <= j)
                {
                    tam = M[i];
                    M[i] = M[j];
                    M[j] = tam;
                    DiChuyenQuickSort(i, j);
                    i++;
                    j--;
                }
            } while (i < j);
            if (First < j) QuickSort(M, First, j);
            if (i < Last) QuickSort(M, i, Last);
        }
        private void DiChuyenQuickSort(int vt1, int vt2)
        {
            Status st = new Status();
            st.Vt1 = vt1;
            st.Vt2 = vt2;
            st.Type = LoaiDiChuyen.DI_LEN_DI_XUONG;
            for (int x = 0; x < HEIGHT; x++)
            {
                backgroundWorker3.ReportProgress(0, st);
                System.Threading.Thread.Sleep(15);
            } // ok làm tiếp
            st.Type = LoaiDiChuyen.QUA_PHAI_QUA_TRAI;
            int WIDTH = Math.Abs(vt1 - vt2) * (SIZE + KHOANGCACHNUT);
            for (int x = 0; x < WIDTH; x++)
            {
                backgroundWorker3.ReportProgress(0, st);
                System.Threading.Thread.Sleep(15);
            }// ok làm tiếp
            st.Type = LoaiDiChuyen.DI_XUONG_DI_LEN;
            for (int x = 0; x < HEIGHT; x++)
            {
                backgroundWorker3.ReportProgress(0, st);
                System.Threading.Thread.Sleep(15);
            }
            st.Type = LoaiDiChuyen.DUNG;
            backgroundWorker3.ReportProgress(0, st);
        }
        private void backgroundWorker3_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Status st = e.UserState as Status; // usertate là lấy giá trị st truyền vào trong hàm
            if (st == null) return;
            if (st.Type == LoaiDiChuyen.DUNG)
            {
                Button tam = Mn[st.Vt2];
                Mn[st.Vt2] = Mn[st.Vt1];
                Mn[st.Vt1] = tam;
                return;
            }
            Button btn1 = Mn[st.Vt1];
            Button btn2 = Mn[st.Vt2];
            if (st.Type == LoaiDiChuyen.DI_LEN_DI_XUONG)
            {
                btn1.Top = btn1.Top - 1;
                btn2.Top = btn2.Top + 1;
            }
            else if (st.Type == LoaiDiChuyen.QUA_PHAI_QUA_TRAI)
            {
                btn1.Left = btn1.Left + 1;
                btn2.Left = btn2.Left - 1;
            }
            else if (st.Type == LoaiDiChuyen.DI_XUONG_DI_LEN)
            {
                btn1.Top = btn1.Top + 1;
                btn2.Top = btn2.Top - 1;
            }
        }
        private void backgroundWorker3_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // kết thúc tiến trình cho nút màu xanh lá cây
            // chữ màu đỏ
            foreach (Button btn in pnNut.Controls) // duyệt danh sách ở trong pnnut
            {
                btn.BackColor = Color.Green;
                btn.ForeColor = Color.White;
            }
            btnSapXep.Enabled = true;// nãi cho mở giờ hiện lại cho người dùng tiếp tục
            btnVeNut.Enabled = true;
        }
        private void backgroundWorker4_DoWork(object sender, DoWorkEventArgs e)
        {
            InsertionSort(M, M.Length);
        }
        private void InsertionSort(int[] a, int n)
        {
            int l, r; //vị trí của mảng con đã xắp sẵn
            l = r = 0;
            for (int i = 1; i < n; i++)
            {
                int vtmin = i;
                int vtchen = -1;
                int gtmin = a[i];
                // tìm vị trí min
                for (int j = i + 1; j < n; j++)
                {
                    if (a[j] < gtmin)
                    {
                        vtmin = j;
                        gtmin = a[j];
                    }
                }
                // tìm vị trí cần chèn
                for (int h = l; h <= r; h++)
                {
                    if (a[h] > gtmin)
                        vtchen = h;
                }
                // dịch chuyển mảng

                if (vtchen != -1) // TH
                {
                    for (int k = vtmin; k > vtchen; k--)
                    {
                        a[k] = a[k - 1];
                    }
                    DoiViTri(vtchen, vtmin);
                    // gán gt 
                    a[vtchen] = gtmin;
                }
                r++;
            }
        }
        private void DoiViTri(int vt1, int vt2)
        {
            Status st = new Status();
            st.Vt1 = vt1;
            st.Vt2 = vt2;
            st.Type = LoaiDiChuyen.DI_LEN_DI_XUONG; // từ trên đi xuống
            for (int x = 0; x < HEIGHT; x++)
            {
                backgroundWorker4.ReportProgress(0, st);
                System.Threading.Thread.Sleep(5);
            } // ok làm tiếp
            st.Type = LoaiDiChuyen.DOI_VI_TRI;
            for (int x = 0; x < HEIGHT; x++)
            {
                backgroundWorker4.ReportProgress(0, st);
                System.Threading.Thread.Sleep(5);
            } // ok làm tiếp
            st.Type = LoaiDiChuyen.QUA_PHAI_QUA_TRAI; // từ trên đi xuống
            int WIDTH = Math.Abs(vt1 - vt2) * (SIZE + KHOANGCACHNUT);
            for (int x = 0; x < WIDTH; x++)
            {
                backgroundWorker4.ReportProgress(0, st);
                System.Threading.Thread.Sleep(5);
            } // ok làm tiếp
            st.Type = LoaiDiChuyen.DI_XUONG_DI_LEN; // từ dưới đi lên
            for (int x = 0; x < HEIGHT; x++)
            {
                backgroundWorker4.ReportProgress(0, st);
                System.Threading.Thread.Sleep(5);
            }
            st.Type = LoaiDiChuyen.DUNG;
            backgroundWorker4.ReportProgress(0, st);
        }

        private void backgroundWorker4_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Status st = e.UserState as Status; // usertate là lấy giá trị st truyền vào trong hàm
            if (st == null) return;
            if (st.Type == LoaiDiChuyen.DUNG)
            {
                Button tam = Mn[st.Vt2];
                for (int i = st.Vt2; i > st.Vt1; i--)
                {
                    Mn[i] = Mn[i - 1];
                }
                Mn[st.Vt1] = tam;
                return;
            }
            Button btn1 = Mn[st.Vt1];
            Button btn2 = Mn[st.Vt2];
            if (st.Type == LoaiDiChuyen.DI_LEN_DI_XUONG)
            {
                //btn1.Top = btn1.Top - 1;
                btn2.Top = btn2.Top + 1;
            }
            else if (st.Type == LoaiDiChuyen.QUA_PHAI_QUA_TRAI)
            {
                //btn1.Left = btn1.Left + 1;
                btn2.Left = btn2.Left - 1;
            }
            else if (st.Type == LoaiDiChuyen.DI_XUONG_DI_LEN)
            {
                //btn1.Top = btn1.Top + 1;
                btn2.Top = btn2.Top - 1;
            }
            else if (st.Type == LoaiDiChuyen.DOI_VI_TRI)
            {
                for (int i = st.Vt1; i < st.Vt2; i++)
                {
                    Mn[i].Left = Mn[i].Left + 1;
                }
            }
        }

        private void backgroundWorker4_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // kết thúc tiến trình cho nút màu xanh lá cây
            // chữ màu đỏ
            foreach (Button btn in pnNut.Controls) // duyệt danh sách ở trong pnnut
            {
                btn.BackColor = Color.Green;
                btn.ForeColor = Color.White;
            }
            btnSapXep.Enabled = true;// nãi cho mở giờ hiện lại cho người dùng tiếp tục
            btnVeNut.Enabled = true;
        }

        private void backgroundWorker5_DoWork(object sender, DoWorkEventArgs e)
        {
            SelectionSort(M, M.Length);
        }

        private void SelectionSort(int[] a, int n)
        {
            for (int i = 0; i < n - 1; i++)         //i = bước
            {
                //Tìm min từ i đến hết mảng
                int min = a[i];
                int vtmin = i;
                for (int j = i + 1; j < n; j++)
                    if (min > a[j])
                    {
                        min = a[j];
                        vtmin = j;
                    }
                //Hoán đổi giá trị a[i] và a[vtmin]
                int t = a[i];
                a[i] = a[vtmin];
                a[vtmin] = t;
                DiChuyenInterchangeSort(vtmin, i);
            }

        }



        private void backgroundWorker5_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Status st = e.UserState as Status; // usertate là lấy giá trị st truyền vào trong hàm
            if (st == null) return;
            if (st.Type == LoaiDiChuyen.DUNG)
            {
                Button tam = Mn[st.Vt2];
                Mn[st.Vt2] = Mn[st.Vt1];
                Mn[st.Vt1] = tam;
                return;
            }
            Button btn1 = Mn[st.Vt1];
            Button btn2 = Mn[st.Vt2];
            if (st.Type == LoaiDiChuyen.DI_LEN_DI_XUONG)
            {
                btn1.Top = btn1.Top - 1;
                btn2.Top = btn2.Top + 1;
            }
            else if (st.Type == LoaiDiChuyen.QUA_PHAI_QUA_TRAI)
            {
                btn1.Left = btn1.Left - 1;
                btn2.Left = btn2.Left + 1;
            }
            else if (st.Type == LoaiDiChuyen.DI_XUONG_DI_LEN)
            {
                btn1.Top = btn1.Top + 1;
                btn2.Top = btn2.Top - 1;
            }
        }

        private void backgroundWorker5_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // kết thúc tiến trình cho nút màu xanh lá cây
            // chữ màu đỏ
            foreach (Button btn in pnNut.Controls) // duyệt danh sách ở trong pnnut
            {
                btn.BackColor = Color.Green;
                btn.ForeColor = Color.White;
            }
            btnSapXep.Enabled = true;// nãi cho mở giờ hiện lại cho người dùng tiếp tục
            btnVeNut.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtSoNut.Text = "5";
            cboThuatToanSapXep.SelectedIndex = 4;
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            // tạo điều kiện nếu người dùng chọn vào item trong combobox
            if (cboTimKiem.SelectedIndex == -1)
            {
                MessageBox.Show("Bạn lựa chọn thuật toán tìm kiếm");
            }
            else if (cboTimKiem.SelectedIndex == 0)
            {
                // tiếp theo mình kéo backgroudworker vào giao diện phần mềm
                backgroundWorker6.RunWorkerAsync(); // gọi hàm doword 
            }
            else if (cboTimKiem.SelectedIndex == 1)
            {
                // tiếp theo mình kéo backgroudworker vào giao diện phần mềm
                backgroundWorker7.RunWorkerAsync(); // gọi hàm doword 
            }
        }

        private void backgroundWorker6_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < M.Length; i++)
            {
                Mn[i].BackColor = Color.White;
                Mn[i].ForeColor = Color.Black;
            }
            int x = Convert.ToInt32(txtGT.Text);
            int kq = SearchTuyenTinh(M, x);
            if (kq != -1) MessageBox.Show("Tìm Thấy");
            else MessageBox.Show("Không Tìm Thấy !!!");
        }

        private int SearchTuyenTinh(int[] m, int x)
        {
            for (int i = 0; i < m.Length; i++)
            {
                //DiChuyenTuyenTinh(M,i);
                Mn[i].BackColor = Color.Green;
                Mn[i].ForeColor = Color.White;
                System.Threading.Thread.Sleep(1550);
                if (m[i] == x)
                {
                    Mn[i].BackColor = Color.Red;
                    Mn[i].ForeColor = Color.Yellow;
                    return i;
                }
                Mn[i].BackColor = Color.White;
                Mn[i].ForeColor = Color.Black;
            }
            return -1;
        }
        private void backgroundWorker7_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < M.Length; i++)
            {
                Mn[i].BackColor = Color.White;
                Mn[i].ForeColor = Color.Black;
            }
            // sắp xếp tăng dần
            int x = Convert.ToInt32(txtGT.Text);
            int kq = BinarySearch(M, x);
            if (kq != -1) MessageBox.Show("Tìm Thấy");
            else MessageBox.Show("Không Tìm Thấy !!!");
        }
        private int BinarySearch(int[] m, int x)
        {
            int left = 0;
            int right = m.Length - 1;
            Mn[left].BackColor = Color.Green;
            Mn[right].BackColor = Color.Green;
            System.Threading.Thread.Sleep(1550);
            int midle;
            do
            {
                midle = (left + right) / 2;
                if (x == m[midle])
                {
                    Mn[left].BackColor = Color.White;
                    Mn[right].BackColor = Color.White;
                    Mn[midle].BackColor = Color.Red;
                    System.Threading.Thread.Sleep(1000);
                    return midle;   //Thấy x tại mid
                }
                else
                    if (x < m[midle])
                {
                    Mn[right].BackColor = Color.White;
                    right = midle - 1;
                    Mn[right].BackColor = Color.Green;
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
                    Mn[left].BackColor = Color.White;
                    left = midle + 1;
                    Mn[left].BackColor = Color.Green;
                    System.Threading.Thread.Sleep(1000);
                }
            } while (left <= right);
            return -1;
            // Tìm hết dãy mà không có x
        }
        private void btnThemGT_Click(object sender, EventArgs e)
        {
            if (txtThemGT.TextLength == 0) MessageBox.Show("Nhập giá trị cần thêm!");
            else
            {

                Button btn = new Button();
                Array.Resize(ref M, M.Length + 1);
                Array.Resize(ref Mn, Mn.Length + 1);
                // lấy giá trị ngẫu nhiên từ 0 đến 99
                //int value = b[i];
                int value = Convert.ToInt32(txtThemGT.Text); ;
                btn.Text = value + ""; // thêm giá trị số ngẫu nhiên vào nút
                btn.Width = btn.Height = SIZE;
                // tạo vị trí button trên giao diện hàm point vẽ button trên trục x và y
                // đổi số 1 là trục x, đổi số 2 trong hàm là trục y
                btn.Location = new Point(KHOANGCACHNUT + pnNut.Controls.Count * (btn.Width + KHOANGCACHNUT), pnNut.Height / 2 - btn.Height / 2); // cho nút xuất hiện ở giữa trong pnNut
                btn.BackColor = Color.White;
                pnNut.Controls.Add(btn);
                // gán giá trị số ngẫu nhiên cho từng phần tử mảng
                // gán từng nút cho mảng Mn
                M[M.Length - 1] = value;
                Mn[Mn.Length - 1] = btn;

            }
        }
    }
}

