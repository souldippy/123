﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CT_mo_phong_thuat_toan_sap_xep
{
    public enum LoaiDiChuyen
    {
        // nút lênh 1 tại vt1, đi lên, qua phải, đi xuống
        // nút lệnh 2 đi xuống , qua trái , đi lên
        // tạo hành động cho nút lệnh di chuyển
        DI_LEN_DI_XUONG,QUA_PHAI_QUA_TRAI,DI_XUONG_DI_LEN,DUNG,DOI_VI_TRI
    }
    // vị trí lúc di chuyển
    public class Status
    {
        public LoaiDiChuyen Type { get; set; }
        public int Vt1 { get; set; }
        public int Vt2 { get; set; }
    }
}
