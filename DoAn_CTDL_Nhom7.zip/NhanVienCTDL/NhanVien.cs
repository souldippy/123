﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NhanVienCTDL
{
    public class SinhVien
    {
        private string mMaSV;
        private string tTenSV;
        private int nNamSinh;
        private bool gGioiTinh;
        private double dDiemToan;
        private double dDiemTin;
        private double dDiemTB;

        public string MaSV
        {
            get { return this.mMaSV; }
            set { this.mMaSV = value; }
        }
        public string TenSV
        {
            get { return this.tTenSV; }
            set { this.tTenSV = value; }
        }
        public int Namsinh
        {
            get { return this.nNamSinh; }
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException($"{nameof(value)} nam sinh > 0 ");
                this.nNamSinh = value;
            }
        }
        public bool GioiTinh
        {
            get { return this.gGioiTinh; }
            set { this.gGioiTinh = value; }
        }
       
        public double DiemToan
        {
            get { return this.dDiemToan; }
            set {
                if (value < 0 || value >10)
                    throw new ArgumentOutOfRangeException($"{nameof(value)} phai >= 0 va <=10");
                this.dDiemToan = value; }
        }
        public double DiemTin
        {
            get { return this.dDiemTin; }
            set
            {
                if (value < 0 || value > 10)
                    throw new ArgumentOutOfRangeException($"{nameof(value)} phai >= 0 va <=10");
                this.dDiemTin = value;
            }
        }
        public double DiemTB
        {
            get { return this.dDiemTB; }
        }

        public SinhVien()
        {
        }
        // TÍnh đtb
        public void TinhDTB()
        {
            dDiemTB = (double)(DiemToan + DiemTin) / 2;
        }
    }
}
