﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; //Nhập xuất FIle

namespace NhanVienCTDL
{
    public partial class Form1 : Form
    {
        List<SinhVien> dDSSV;
        public Form1()
        {
            InitializeComponent();
        }


        private bool KiemTraID(string id) // false là trùng
        {
            for(int i=0;i<dDSSV.Count;i++)
            {
                if (dDSSV[i].MaSV == id) return false;
            }
            return true;
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            if (KiemTraID(txtID.Text) == false)
            {
                MessageBox.Show("ID bị trùng, vui lòng nhập lại!");
                return;
            }
            SinhVien sv = new SinhVien();
            sv.TenSV = txtHoVaTen.Text;
            sv.MaSV = txtID.Text;
            if (rdNam.Checked == true) sv.GioiTinh = true;
            else sv.GioiTinh = false;
            sv.Namsinh = Convert.ToInt32(txtNamSinh.Text);
            sv.DiemToan = Convert.ToDouble(txtDiemToan.Text);
            sv.DiemTin = Convert.ToDouble(txtDiemTin.Text);
            sv.TinhDTB();
            this.dDSSV.Add(sv);
            // thêm nv vào list danh sách
            lstDanhSach.Items.Add(sv.TenSV);
            this.ActiveControl = txtHoVaTen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            dDSSV = new List<SinhVien>();
            Docfile();
        }

        private void Docfile()
        {
            // hiện thị hộp thoại Mở tập tin
            DialogResult dr = openDialog.ShowDialog();
            if (dr == DialogResult.OK)
            {
                StreamReader sw = new StreamReader(openDialog.FileName);
                // ghi dữ liệu
                int n = Convert.ToInt32(sw.ReadLine());

                for (int i = 0; i < n; i++)
                {
                    SinhVien sv = new SinhVien();
                    sv.TenSV = sw.ReadLine();
                    sv.MaSV = sw.ReadLine();
                    string gt = sw.ReadLine();
                    if (gt == "True") sv.GioiTinh = true;
                    else sv.GioiTinh = false;
                    sv.Namsinh = Convert.ToInt32(sw.ReadLine());
                    sv.DiemToan = Convert.ToDouble(sw.ReadLine());
                    sv.DiemTin = Convert.ToDouble(sw.ReadLine());
                    sv.TinhDTB();
                    this.dDSSV.Add(sv);
                    // thêm nv vào list danh sách
                    lstDanhSach.Items.Add(sv.TenSV);
                }
                sw.Close();
            }

        }

        private void lstDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDanhSach.SelectedIndex == -1) lstDanhSach.SelectedIndex = 0;
            //lấy thông tin nv đang được chọn đổ ra form
            SinhVien nv = dDSSV[lstDanhSach.SelectedIndex];
            txtHoVaTen.Text = nv.TenSV;
            txtID.Text = nv.MaSV.ToString();
            rdNam.Checked = nv.GioiTinh;
            rdNu.Checked = !nv.GioiTinh;
            txtNamSinh.Text = nv.Namsinh.ToString();
            txtDiemToan.Text = nv.DiemToan.ToString();
            txtDiemTin.Text = nv.DiemTin.ToString();
            txtDiemTB.Text = nv.DiemTB.ToString();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            int vt = lstDanhSach.SelectedIndex; // lấy vị trí nv cần xóa
            if (vt == -1)// chưa chọn
                MessageBox.Show("Bạn Chưa Chọn Nhân Viên!!!");
            else
            {
                dDSSV.RemoveAt(vt); // xóa trên list
                lstDanhSach.Items.RemoveAt(vt); // xóa trên danh sách hiển thị

            }
        }
        private void btnSapXep_Click(object sender, EventArgs e)
        {
            if (cboSapXep.SelectedIndex == -1)
                MessageBox.Show("Chọn Kiểu Sắp Xếp!!!");
            else if (cboSapXep.SelectedIndex == 0)
            {
                for (int i = 0; i < dDSSV.Count - 1; i++)
                    for (int j = i + 1; j < dDSSV.Count; j++)
                        if (dDSSV[i].DiemTB <= dDSSV[j].DiemTB)
                        {
                            SinhVien t = dDSSV[i];
                            dDSSV[i] = dDSSV[j];
                            dDSSV[j] = t;
                        }
                CapNhatLST();
            }
            else if (cboSapXep.SelectedIndex == 1)
            {
                lstDanhSach.SelectedIndex = 0;
                for (int i = 0; i < dDSSV.Count - 1; i++)
                    for (int j = i + 1; j < dDSSV.Count; j++)
                        if (dDSSV[i].DiemTB >= dDSSV[j].DiemTB)
                        {
                            SinhVien t = dDSSV[i];
                            dDSSV[i] = dDSSV[j];
                            dDSSV[j] = t;
                        }
                CapNhatLST();
            }
        }

        private void CapNhatLST()
        {
            lstDanhSach.SelectedIndex = 0;
            for (int i = 0; i < dDSSV.Count; i++)
            {
                //lstDanhSach.SelectedIndex = 0;
                SinhVien nv = dDSSV[i];
                lstDanhSach.Items[i] = nv.TenSV;
                //lstDanhSach.Controls.e;
            }
        }


        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            if (cboTimKiem.SelectedIndex == 0)
            {
                if (txtTimKiem.Text == "") MessageBox.Show("Nhập Thông tin cần tìm !!!");

                int kq = TimKiemTT(txtTimKiem.Text);
                if (kq == -1) MessageBox.Show("Không Tìm thấy");
                else
                {
                    lstDanhSach.SelectedIndex = kq;
                    MessageBox.Show("Tìm thấy");
                }
            }
            else if (cboTimKiem.SelectedIndex == 1)
            {
                if (txtTimKiem.Text == "") MessageBox.Show("Nhập Thông tin cần tìm !!!");

                int kq = TimKiemMSSV(txtTimKiem.Text);
                if (kq == -1) MessageBox.Show("Không Tìm thấy");
                else
                {
                    lstDanhSach.SelectedIndex = kq;
                    MessageBox.Show("Tìm thấy");
                }
            }
            else if (cboTimKiem.SelectedIndex == 2)
            {
                //if (txtTimKiem.Text == "") MessageBox.Show("Nhập Thông tin cần tìm !!!");

                int kq = TimKiemSVDTBMAX();
                lstDanhSach.SelectedIndex = kq;
                MessageBox.Show("Tìm thấy");
            }
        }

        private int TimKiemMSSV(string mssv)
        {
            for (int i = 0; i < dDSSV.Count; i++)
                if (dDSSV[i].MaSV == mssv)
                    return i;
            return -1;
        }
        private int TimKiemSVDTBMAX()
        {
            int vt = 0;
            double max = dDSSV[0].DiemTB;
            for (int i = 0; i < dDSSV.Count; i++)
                if (dDSSV[i].DiemTB > max)
                {
                    max = dDSSV[i].DiemTB;
                    vt = i;

                }
            return vt;
        }
        private int TimKiemTT(string text)
        {
            for (int i = 0; i < dDSSV.Count; i++)
                if (dDSSV[i].TenSV == text)
                    return i;
            return -1;
        }

        private void txtTimKiem_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // hiện thị hộp thoại saveAs
            DialogResult dr = saveDialog.ShowDialog();
            if (dr == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(saveDialog.FileName);
                // ghi dữ liệu
                sw.WriteLine(dDSSV.Count); // số SV
                for (int i = 0; i < dDSSV.Count; i++)
                {
                    SinhVien sv = (SinhVien)dDSSV[i]; // ép kiểu
                    sw.WriteLine(sv.TenSV);
                    sw.WriteLine(sv.MaSV);
                    sw.WriteLine(sv.GioiTinh.ToString());
                    sw.WriteLine(sv.Namsinh.ToString());
                    sw.WriteLine(sv.DiemToan.ToString());
                    sw.WriteLine(sv.DiemTin.ToString());
                    // đóng tập tin
                }
                sw.Close();
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dr; // hứng kết quả
            dr = MessageBox.Show("Bạn có muốn thoát không?", "Thong bao", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
                this.Close();
        }

        private void btnDoiThongTin_Click(object sender, EventArgs e)
        {
            if (lstDanhSach.SelectedIndex == -1) MessageBox.Show("Chọn sinh viên muốn thay đổi thông tin!");
            else
            {
                DialogResult dr; // hứng kết quả
                dr = MessageBox.Show("Bạn có muốn lưu thay đổi không?", "Thong bao", MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {

                    dDSSV[lstDanhSach.SelectedIndex].TenSV = txtHoVaTen.Text;
                    dDSSV[lstDanhSach.SelectedIndex].MaSV = txtID.Text;
                    dDSSV[lstDanhSach.SelectedIndex].GioiTinh = rdNam.Checked;
                    dDSSV[lstDanhSach.SelectedIndex].Namsinh = Convert.ToInt32(txtNamSinh.Text);
                    dDSSV[lstDanhSach.SelectedIndex].DiemToan = Convert.ToInt32(txtDiemToan.Text);
                    dDSSV[lstDanhSach.SelectedIndex].DiemTin = Convert.ToInt32(txtDiemTin.Text);
                    dDSSV[lstDanhSach.SelectedIndex].TinhDTB();
                }
            }
        }
    }
}
